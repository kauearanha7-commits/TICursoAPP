PROJETO CURSO DE TI

Telas:
1) Tela inicial com temática de TI e botão INICIAR.
2) Mensagem "estamos quase lá..." e botão "avançar", também com temática de TI.
3) Exibe a foto enviada pelo usuário.

Para gerar o APK: abra esta pasta no Android Studio e use Build > Build APK(s).
O projeto usa Java e Android Gradle Plugin 8.6.1.
