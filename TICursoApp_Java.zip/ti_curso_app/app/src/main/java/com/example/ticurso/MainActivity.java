package com.example.ticurso;

import android.app.Activity;
import android.os.Bundle;
import android.graphics.Color;
import android.graphics.drawable.GradientDrawable;
import android.view.Gravity;
import android.view.View;
import android.widget.*;
import android.graphics.drawable.ColorDrawable;

public class MainActivity extends Activity {
    LinearLayout root;
    int white = Color.WHITE;
    @Override public void onCreate(Bundle b) { super.onCreate(b); showFirst(); }

    TextView text(String s, float size, int color) {
        TextView t = new TextView(this); t.setText(s); t.setTextSize(size); t.setTextColor(color); t.setGravity(Gravity.CENTER); return t;
    }
    Button button(String s) {
        Button b = new Button(this); b.setText(s); b.setTextSize(15); b.setTextColor(Color.rgb(4,16,27)); b.setAllCaps(false);
        GradientDrawable g = new GradientDrawable(); g.setColor(Color.rgb(0,184,212)); g.setCornerRadius(18); b.setBackground(g); return b;
    }
    LinearLayout base() { LinearLayout l = new LinearLayout(this); l.setOrientation(LinearLayout.VERTICAL); l.setGravity(Gravity.CENTER); l.setPadding(32,32,32,32); GradientDrawable g=new GradientDrawable(GradientDrawable.Orientation.TL_BR,new int[]{Color.rgb(5,11,24),Color.rgb(16,27,58),Color.rgb(23,10,47)}); l.setBackground(g); return l; }
    void showFirst() {
        root=base(); TextView tag=text("CURSO DE TI",16,Color.rgb(0,229,255)); tag.setTypeface(null,1); root.addView(tag);
        TextView title=text("TECNOLOGIA\nCOMEÇA AQUI",34,white); title.setTypeface(null,1); LinearLayout.LayoutParams tp=new LinearLayout.LayoutParams(-2,-2); tp.setMargins(0,18,0,0); root.addView(title,tp);
        TextView sub=text("Prepare-se para entrar no mundo da tecnologia.",16,Color.rgb(184,199,230)); LinearLayout.LayoutParams sp=new LinearLayout.LayoutParams(-1,-2); sp.setMargins(0,18,0,0); root.addView(sub,sp);
        Button start=button("INICIAR"); LinearLayout.LayoutParams bp=new LinearLayout.LayoutParams(-2,60); bp.setMargins(0,36,0,0); root.addView(start,bp); start.setOnClickListener(v->showSecond()); setContentView(root);
    }
    void showSecond() {
        root=base(); TextView icon=text("</>",42,Color.rgb(0,229,255)); icon.setTypeface(null,1); root.addView(icon);
        TextView msg=text("estamos quase lá...",28,white); msg.setTypeface(null,1); LinearLayout.LayoutParams mp=new LinearLayout.LayoutParams(-1,-2); mp.setMargins(0,22,0,0); root.addView(msg,mp);
        TextView sub=text("Seu próximo passo está pronto.\nClique abaixo para continuar.",16,Color.rgb(184,199,230)); LinearLayout.LayoutParams sp=new LinearLayout.LayoutParams(-1,-2); sp.setMargins(0,14,0,0); root.addView(sub,sp);
        Button next=button("avançar"); LinearLayout.LayoutParams bp=new LinearLayout.LayoutParams(-2,60); bp.setMargins(0,34,0,0); root.addView(next,bp); next.setOnClickListener(v->showThird()); setContentView(root);
    }
    void showThird() {
        FrameLayout frame=new FrameLayout(this); frame.setBackgroundColor(Color.BLACK);
        ImageView image=new ImageView(this); image.setImageResource(com.example.ticurso.R.drawable.pessoa); image.setScaleType(ImageView.ScaleType.CENTER_CROP); frame.addView(image,new FrameLayout.LayoutParams(-1,-1));
        TextView done=text("SEJA BEM-VINDO!",22,Color.WHITE); done.setTypeface(null,1); done.setBackgroundColor(0x66000000); FrameLayout.LayoutParams dp=new FrameLayout.LayoutParams(-1,70,Gravity.BOTTOM); dp.setMargins(20,0,20,20); frame.addView(done,dp); setContentView(frame);
    }
}
